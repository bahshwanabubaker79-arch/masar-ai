import { AnalysisReport, OptimizationReport, InterviewPack, AnswerEvaluation } from "@/types/agents";

export const SAMPLE_DATA = {
  ar: {
    resume: `سعود المنصور
مهندس برمجيات خريج حديث - جامعة الملك سعود
البريد: saud@example.com | الرياض، المملكة العربية السعودية

النبذة المهنية:
خريج علوم حاسب طموح، لدي شغف بتطوير الويب وحل المشكلات البرمجية. أبحث عن فرصة عمل كمهندس برمجيات مبتدئ لاكتساب الخبرة وتطوير مهاراتي.

المهارات:
JavaScript, HTML, CSS, React, Git, Python basics, SQL.

المشاريع الأكاديمية:
- مشروع التخرج: منصة إدارة مهام جامعية باستخدام React و Node.js.
  * قمت ببناء واجهات المستخدم وتصميم النماذج.
  * عملت مع الفريق لتسليم المشروع في الوقت المحدد.
  * استخدمت قواعد بيانات MongoDB لحفظ بيانات المهام.
- متجر إلكتروني مصغر:
  * تطبيق ويب بلغة JavaScript لتصفح وشراء المنتجات.
  * ربط الواجهة مع واجهة برمجية وهمية (Mock API).`,

    jobDescription: `مطلوب مهندس برمجيات واجهات أمامية (Frontend Engineer) - الرياض

المسؤوليات:
- بناء واجهات وتطبيقات ويب سريعة وقابلة للتوسع باستخدام Next.js و TypeScript.
- تطبيق أحدث معايير الأداء والـ Core Web Vitals وتصميم متجاوب مع Tailwind CSS.
- التكامل مع واجهات برمجة التطبيقات RESTful APIs و GraphQL.
- كتابة اختبارات آلية واختبارات الوحدة باستخدام Jest أو Playwright.
- العمل وفق منهجية Agile/Scrum والتعاون مع فرق الـ Backend والمنتج.
- استخدام أدوات الـ CI/CD (مثل GitHub Actions) ونشر التطبيقات على Vercel أو AWS.

المتطلبات:
- بكالوريوس في علوم الحاسب أو مجال ذي صلة.
- خبرة عملية قوية في React, Next.js, TypeScript.
- إتقان أدوات إدارة الحالة (State Management مثل Redux Toolkit أو Zustand).
- معرفة جيدة بأنظمة الفحص الآلي والـ Clean Code.`
  },

  en: {
    resume: `Saud Al-Mansoor
Junior Software Engineer - King Saud University
Email: saud@example.com | Riyadh, Saudi Arabia

Professional Summary:
Motivated Computer Science graduate with a strong passion for web development and problem-solving. Looking for an entry-level software engineering role to grow technical skills and contribute to impactful projects.

Skills:
JavaScript, HTML, CSS, React, Git, Python basics, SQL.

Academic & Personal Projects:
- Senior Capstone Project: University Task Management Portal (React & Node.js)
  * Developed user interfaces and designed form components.
  * Collaborated with team members to deliver the capstone on schedule.
  * Utilized MongoDB to store user task records.
- Mini E-Commerce App:
  * Built a responsive storefront using vanilla JavaScript to browse and buy products.
  * Connected UI to a mock REST API for mock checkout flows.`,

    jobDescription: `Frontend Software Engineer - Riyadh

Responsibilities:
- Build blazing-fast, scalable web applications using Next.js and TypeScript.
- Optimize performance, Core Web Vitals, and maintain responsive UI with Tailwind CSS.
- Integrate with RESTful APIs and GraphQL endpoints.
- Write unit and end-to-end tests using Jest or Playwright.
- Collaborate in an Agile/Scrum environment with backend engineers and product managers.
- Manage CI/CD pipelines (GitHub Actions) and deploy to cloud platforms (Vercel/AWS).

Requirements:
- Bachelor's degree in Computer Science or equivalent.
- Strong hands-on experience with React, Next.js, and TypeScript.
- Proficiency with modern state management (e.g., Redux Toolkit or Zustand).
- Understanding of automated testing and Clean Code principles.`
  }
};

export const MOCK_ANALYSIS_AR: AnalysisReport = {
  atsScore: 54,
  matchLevel: "medium",
  candidateSummary: "مرشح واعد يملك أساساً جيداً في علوم الحاسب وReact، لكن السيرة الذاتية تفتقر للكلمات المفتاحية الأساسية للوظيفة (TypeScript, Next.js, CI/CD, Automated Testing) وصياغة الإنجازات عامة ولا تحتوي مقاييس رقمية.",
  targetRole: "Frontend Software Engineer",
  strengths: [
    "خلفية أكاديمية متينة في علوم الحاسب من جامعة معتمدة",
    "خبرة أساسية في مكتبة React وJavaScript وإدارة الإصدارات بـ Git",
    "مشاريع مكتملة شملت بناء واجهات والربط مع قواعد بيانات وواجهات API"
  ],
  missingKeywords: [
    { keyword: "TypeScript", priority: "high", reason: "شرط أساسي إلزامي في الوصف الوظيفي لضمان جودة الأكواد الضخمة" },
    { keyword: "Next.js", priority: "high", reason: "إطار العمل الرئيسي المحدد في متطلبات الوظيفة للمشروع" },
    { keyword: "Tailwind CSS", priority: "high", reason: "المعيار المطلوب لبناء الواجهات المتجاوبة وسرعة التطوير" },
    { keyword: "Automated Testing (Jest / Playwright)", priority: "medium", reason: "مطلب لضمان استقرار التطبيقات قبل النشر" },
    { keyword: "CI/CD & GitHub Actions", priority: "medium", reason: "ضروري لأتمتة عمليات الفحص والنشر السحابي" },
    { keyword: "State Management (Zustand / Redux)", priority: "medium", reason: "مطلوب للتعامل مع البيانات المعقدة في الواجهات" }
  ],
  skillGaps: [
    { area: "إطارات العمل الحديثة", issue: "عدم ذكر Next.js أو TypeScript نهائياً", impact: "استبعاد فوري من فلاتر ATS التلقائية التي تبحث عن Next.js" },
    { area: "قياس الإنجازات (Impact Metrics)", issue: "النقاط تصرفية بحتة (قمت ببناء، عملت مع الفريق) دون أرقام أو نتائج", impact: "انطباع بقلة الخبرة العملية ومستوى مبتدئ جداً" },
    { area: "اختبار البرمجيات والجودة", issue: "غياب أدوات الاختبار مثل Jest أو منهجيات Clean Code", impact: "تخوف فريق التوظيف من جودة الأكواد المنتجة" }
  ],
  handoffToOptimizer: "وكيل الفرز إلى وكيل التحسين: يُرجى إعادة صياغة النبذة المهنية وتضمين مهارات Next.js وTypeScript وTailwind CSS بشكل طبيعي، وتحويل نقاط مشروع التخرج إلى أسلوب XYZ مع إضافة مقاييس أداء وسرعة تحميل ومحاكاة بيئة Agile.",
  handoffToInterviewer: "وكيل الفرز إلى وكيل المقابلات: المرشح لم يذكر خبرة عملية موثقة في TypeScript وNext.js واختبارات الوحدة. ركّز أسئلتك على التحقق من فهمه العميق للـ Type Safety والـ SSR، وسؤاله عن كيفية اختباره للمشاريع التي أنجزها."
};

export const MOCK_OPTIMIZATION_AR: OptimizationReport = {
  projectedAtsScore: 88,
  scoreImprovementNote: "ارتفاع متوقع من 54% إلى 88% بعد تضمين الكلمات المفتاحية الحرجة وصياغة الإنجازات بأسلوب XYZ القياسي المعترف به في كبرى الشركات.",
  optimizedSummary: "مهندس برمجيات واجهات أمامية متخصص في تطوير تطبيقات ويب تفاعلية وسريعة الاستجابة باستخدام React وNext.js وTypeScript. أتمتع بخبرة في بناء الواجهات المتجاوبة بواسطة Tailwind CSS والربط مع RESTful APIs وفق مبادئ Clean Code. أسعى للمساهمة في بناء منتجات رقمية قابلة للتوسع ضمن فريق Agile سريع النمو.",
  rewrittenBullets: [
    {
      original: "قمت ببناء واجهات المستخدم وتصميم النماذج.",
      improved: "طوّرت أكثر من 12 واجهة مستخدم متجاوبة ونماذج إدخال مؤتمتة باستخدام Next.js وTypeScript وTailwind CSS، مما قلل وقت تحميل الصفحات بنسبة 35% وحقق معايير Core Web Vitals الممتازة.",
      keywordsAdded: ["Next.js", "TypeScript", "Tailwind CSS", "Core Web Vitals"],
      rationale: "تحويل مهمة روتينية إلى إنجاز ملموس يقيس الأداء ويضيف 4 كلمات مفتاحية إجبارية في الوصف الوظيفي."
    },
    {
      original: "عملت مع الفريق لتسليم المشروع في الوقت المحدد.",
      improved: "تعاونت ضمن فريق عمل خماسي باتباع منهجية Agile/Scrum عبر دورات Sprint أسبوعية، مع إدارة الإصدارات عبر Git وإنشاء مسار CI/CD مبسط بواسطة GitHub Actions لأتمتة النشر.",
      keywordsAdded: ["Agile/Scrum", "CI/CD", "GitHub Actions", "Sprint"],
      rationale: "إثبات قدرات العمل الجماعي وفق بيئات العمل الاحترافية المطلوبة تماماً في إعلان الوظيفة."
    },
    {
      original: "استخدمت قواعد بيانات MongoDB لحفظ بيانات المهام.",
      improved: "صممت وهيكلت مخططات البيانات في MongoDB مع تكامل آمن عبر RESTful API ومعالجة الحالة محلياً باستخدام Zustand، مما ضمن مزامنة فورية للبيانات بدون أخطاء.",
      keywordsAdded: ["RESTful API", "Zustand", "State Management", "MongoDB"],
      rationale: "إظهار مهارة إدارة الحالة (State Management) والتعامل الاحترافي مع البيانات والواجهات البرمجية."
    }
  ],
  suggestedSkills: [
    "Next.js 14/15", "TypeScript", "Tailwind CSS", "State Management (Zustand)",
    "RESTful APIs & GraphQL", "CI/CD (GitHub Actions)", "Jest & Testing Library", "Agile & Scrum"
  ],
  atsFormattingTips: [
    "استخدم خطوطاً قياسية تدعم الـ ATS وتجنب الجداول المزدوجة المعقدة والأيقونات الرسومية داخل نصوص المهارات.",
    "احرص على كتابة المسميات الوظيفية والمصطلحات التقنية بدقة كما وردت في إعلان الوظيفة تماماً (مثل Next.js بدلاً من Nextjs).",
    "اجعل كل نقطة خبرة تبدأ بفعل ماضٍ قوي (طوّرت، صممت، قادت، حسّنت) وتنتهي بأثر رقمي ملموس."
  ],
  handoffToInterviewer: "وكيل التحسين إلى وكيل المقابلات: تم تحديث السيرة الذاتية بنجاح بإضافة مشاريع Next.js مع TypeScript وتحسين الأداء. اختبر المرشح في المقابلة حول: كيف قام بتحسين Core Web Vitals عملياً، وكيف يتعامل مع الأنواع المعقدة في TypeScript."
};

export const MOCK_INTERVIEWS_AR: InterviewPack = {
  interviewStrategy: "استراتيجية المقابلة: التركيز على قياس صحة المهارات الجديدة المضافة (TypeScript و Next.js)، والتحقق من الفهم العملي لمنهجية STAR، واختبار قدرة المرشح على سد الفجوات التقنية التي رصدها وكيل الفرز.",
  questions: [
    {
      id: "q-1",
      sourceAgent: "analyzer",
      targetFocus: "فجوة المهارات: اختبارات الوحدة (Automated Testing)",
      category: "gap-probe",
      difficulty: "medium",
      question: "لاحظنا في سيرتك الذاتية تركيزك على بناء الواجهات، كيف تضمن عادةً خلو كود الـ React من الأخطاء قبل إطلاقه للإنتاج؟ وما تجربتك مع مكتبات مثل Jest؟",
      whyAsked: "رصد وكيل الفرز غياب اختبارات الوحدة من السيرة الذاتية، وهذا السؤال يتحقق مما إذا كان المرشح يمتلك الحد الأدنى من ثقافة الجودة والاختبار.",
      hint: "اذكر الفرق بين اختبار المكونات المنفصلة والاختبار التكاملي، وتحدث عن دور أداة مثل React Testing Library.",
      idealPoints: [
        "ذكر كتابة Unit Tests للوظائف الحسابية والمكونات المعزولة",
        "محاكاة استجابات الـ API (Mocking) للتأكد من حالة التحميل والخطأ",
        "تأكيد أهمية الاختبار في تقليل أخطاء الـ Regression في بيئة Agile"
      ]
    },
    {
      id: "q-2",
      sourceAgent: "optimizer",
      targetFocus: "التحقق من الخبرة المحدثة: تحسين أداء الواجهات و Core Web Vitals",
      category: "experience-verify",
      difficulty: "hard",
      question: "ذكرتَ أنكَ قمتَ بتحسين وقت تحميل الصفحات بنسبة 35% في مشروعك باستخدام Next.js. ما هي الخطوات التقنية المحددة التي اتخذتها لتحقيق هذا التحسين في Core Web Vitals؟",
      whyAsked: "أضاف وكيل التحسين أرقاماً متقدمة لتحسين الأداء؛ هذا السؤال يختبر صدق المرشح وعمق فهمه لتقنيات مثل SSR والـ Lazy Loading والـ Image Optimization.",
      hint: "تحدث عن استخدام مكون Next Image، وتقليل حجم حزم الجافاسكربت (Code Splitting)، واستخدام Server Components.",
      idealPoints: [
        "استخدام Next.js Server Components لتقليل حجم الـ Bundle المرسل للعميل",
        "تحسين الصور عبر next/image لمنع الـ Layout Shift (CLS)",
        "تطبيق التحميل الكسول (Lazy Loading) للمكونات الثقيلة"
      ]
    },
    {
      id: "q-3",
      sourceAgent: "analyzer",
      targetFocus: "الفهم المعماري: إدارة الحالة (State Management)",
      category: "technical",
      difficulty: "medium",
      question: "متى تقرر استخدام مكتبة خارجية لإدارة الحالة مثل Zustand أو Redux، ومتى تكتفي بالـ React Context والـ useState؟ وضح بمثال من مشروعك.",
      whyAsked: "الوظيفة تشترط خبرة في إدارة الحالة لتطبيقات معقدة.",
      hint: "ركز على معدل إعادة التصيير (Re-renders) وحجم البيانات المشتركة بين صفحات متعددة.",
      idealPoints: [
        "استخدام useState للحالة المحلية الخاصة بمكون واحد",
        "استخدام Zustand/Redux عند وجود حالة عامة تتطلب تحديثات متكررة دون إعادة تصيير الشجرة كاملة",
        "ذكر تجربة حقيقية مثل سلة المشتريات أو بيانات المستخدم المسجل"
      ]
    },
    {
      id: "q-4",
      sourceAgent: "optimizer",
      targetFocus: "السلوك والعمل الجماعي: أسلوب STAR في حل النزاعات التقنية",
      category: "behavioral",
      difficulty: "medium",
      question: "احكِ لي عن موقف خلال عملك الجماعي في مشروع التخرج اختلفتَ فيه مع زميل حول قرار تصميم أو تقنية معينة. كيف تعاملتَ مع الموقف وما هي النتيجة؟ (أجب بأسلوب STAR)",
      whyAsked: "تحقق من مهارات التواصل وحل المشكلات في بيئة فرق العمل التعاونية.",
      hint: "حدد الموقف (Situation)، المهمة (Task)، الإجراء المنطقي الذي اتخذته (Action)، والنتيجة الإيجابية الملموسة (Result).",
      idealPoints: [
        "تحديد سياق الخلاف المهني بدون شخصنة",
        "اللجوء للبيانات أو عمل تجربة مصغرة (Proof of Concept) لحسم القرار",
        "الخروج بحل يخدم مصلحة المشروع والحفاظ على علاقة الفريق الإيجابية"
      ]
    }
  ]
};

export const MOCK_EVALUATION_AR: AnswerEvaluation = {
  score: 85,
  verdict: "إجابة ممتازة ومتوازنة، أظهرت فهماً عملياً واستخدمت عناصر منهجية STAR بوضوح.",
  strengths: [
    "تحديد الإجراءات التقنية الملموسة بدقة وتجنب الإجابات النظرية العامة",
    "تغطية جيدة لمحوري الموقف والنتيجة بالأرقام",
    "ثقة واضحة وإتقان للمصطلحات التقنية المتخصصة"
  ],
  improvements: [
    "يمكن تدعيم الإجابة بذكر العوائق غير المتوقعة التي ظهرت أثناء التنفيذ وكيف تم التغلب عليها",
    "التركيز أكثر على الأثر على تجربة المستخدم النهائي (UX) وليس فقط الأداء الفني البحت"
  ],
  starBreakdown: {
    situation: true,
    task: true,
    action: true,
    result: true
  },
  modelAnswer: "في مشروعي الأخير، واجهنا بطءاً في تحميل الصفحة الرئيسية التي تحتوي على لوحة مهام ثقيلة (الموقف). كانت مهمتي تسريع زمن التحميل إلى أقل من ثانيتين لتحسين تجربة المستخدمين (المهمة). قمت بتحليل الـ Bundle باستخدام أداة Webpack Analyzer، واستبدلت استيراد المكتبات الكبيرة بالتحميل الكسول Dynamic Import، وحولت عرض البيانات إلى Server Components مع تحسين الصور عبر next/image (الإجراء). النتيجة كانت انخفاض زمن أول ظهور للمحتوى (FCP) بنسبة 35% وارتفاع تقييم Lighthouse من 62 إلى 94 (النتيجة)."
};
