import { NextRequest, NextResponse } from "next/server";
import { runAnalyzerAgent } from "@/lib/groq";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { resume, jobDescription, apiKey } = body;

    if (!resume || !jobDescription) {
      return NextResponse.json(
        { error: "Resume and Job Description are required" },
        { status: 400 }
      );
    }

    const headerApiKey = req.headers.get("x-groq-key") || undefined;
    const effectiveKey = apiKey || headerApiKey;

    const startTime = Date.now();
    const result = await runAnalyzerAgent(resume, jobDescription, effectiveKey);
    const durationMs = Date.now() - startTime;

    return NextResponse.json({
      success: true,
      data: result.data,
      source: result.source,
      durationMs,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
