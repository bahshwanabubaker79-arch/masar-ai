import { SYSTEM_PROMPTS } from "./prompts";
import {
  AnalysisReport,
  OptimizationReport,
  InterviewPack,
  AnswerEvaluation,
} from "@/types/agents";
import {
  MOCK_ANALYSIS_AR,
  MOCK_OPTIMIZATION_AR,
  MOCK_INTERVIEWS_AR,
  MOCK_EVALUATION_AR,
} from "./mockData";

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const DEFAULT_MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";

interface CallGroqOptions {
  systemPrompt: string;
  userPrompt: string;
  apiKey?: string;
  model?: string;
  temperature?: number;
}

export async function callGroqJson<T>(options: CallGroqOptions): Promise<{ data: T; source: "groq" | "mock"; error?: string }> {
  const effectiveKey = options.apiKey || process.env.GROQ_API_KEY;

  if (!effectiveKey || effectiveKey === "your_groq_api_key_here") {
    // Graceful fallback to rich mock data
    return { data: null as unknown as T, source: "mock" };
  }

  try {
    const response = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${effectiveKey.trim()}`,
      },
      body: JSON.stringify({
        model: options.model || DEFAULT_MODEL,
        messages: [
          { role: "system", content: options.systemPrompt },
          { role: "user", content: options.userPrompt },
        ],
        response_format: { type: "json_object" },
        temperature: options.temperature ?? 0.3,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.warn(`Groq API returned ${response.status}:`, errText);
      return { data: null as unknown as T, source: "mock", error: `Groq error ${response.status}: ${errText}` };
    }

    const json = await response.json();
    const content = json.choices?.[0]?.message?.content;
    if (!content) {
      return { data: null as unknown as T, source: "mock", error: "Empty content from Groq" };
    }

    const parsed = JSON.parse(content) as T;
    return { data: parsed, source: "groq" };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.warn("Failed to call Groq API, using fallback:", message);
    return { data: null as unknown as T, source: "mock", error: message };
  }
}

// Agent 1: ATS & Requirements Analyzer
export async function runAnalyzerAgent(
  resume: string,
  jobDescription: string,
  apiKey?: string
): Promise<{ data: AnalysisReport; source: "groq" | "mock" }> {
  const userPrompt = `
RESUME TO ANALYZE:
---
${resume}
---

TARGET JOB DESCRIPTION:
---
${jobDescription}
---

Perform full ATS analysis and extract: atsScore (0-100), matchLevel, candidateSummary, targetRole, strengths, missingKeywords, skillGaps, handoffToOptimizer, handoffToInterviewer.
Respond with valid JSON according to system prompt instructions. Write the analysis in the language detected in the input (prefer Arabic if the resume/job is Arabic).
`;

  const result = await callGroqJson<AnalysisReport>({
    systemPrompt: SYSTEM_PROMPTS.ANALYZER,
    userPrompt,
    apiKey,
  });

  if (result.source === "groq" && result.data && result.data.atsScore !== undefined) {
    return { data: result.data, source: "groq" };
  }

  return { data: MOCK_ANALYSIS_AR, source: "mock" };
}

// Agent 2: Resume Optimizer & Rewriter
export async function runOptimizerAgent(
  originalResume: string,
  analysisReport: AnalysisReport,
  apiKey?: string
): Promise<{ data: OptimizationReport; source: "groq" | "mock" }> {
  const userPrompt = `
ORIGINAL RESUME:
---
${originalResume}
---

HANDOFF REPORT FROM AGENT 1 (ANALYZER):
---
ATS Score: ${analysisReport.atsScore}%
Target Role: ${analysisReport.targetRole}
Missing Keywords to inject: ${JSON.stringify(analysisReport.missingKeywords)}
Skill Gaps identified: ${JSON.stringify(analysisReport.skillGaps)}
Agent 1 Handoff Brief: ${analysisReport.handoffToOptimizer}
---

Task:
1. Rewrite the candidate summary.
2. Rewrite weak bullet points from the resume into impactful XYZ achievements that embed the missing keywords naturally.
3. Suggest an updated list of skills.
4. Estimate projected ATS score improvement.
5. Provide handoffToInterviewer brief warning which claims were upgraded.
Respond strictly in valid JSON matching the system schema.
`;

  const result = await callGroqJson<OptimizationReport>({
    systemPrompt: SYSTEM_PROMPTS.OPTIMIZER,
    userPrompt,
    apiKey,
  });

  if (result.source === "groq" && result.data && result.data.projectedAtsScore !== undefined) {
    return { data: result.data, source: "groq" };
  }

  return { data: MOCK_OPTIMIZATION_AR, source: "mock" };
}

// Agent 3: Interview Coach
export async function runInterviewerAgent(
  analysisReport: AnalysisReport,
  optimizationReport: OptimizationReport,
  apiKey?: string
): Promise<{ data: InterviewPack; source: "groq" | "mock" }> {
  const userPrompt = `
COLLABORATIVE BRIEF FROM PREVIOUS AGENTS:
---
[Agent 1 Analyzer Brief]:
Target Role: ${analysisReport.targetRole}
Identified Gaps: ${JSON.stringify(analysisReport.skillGaps)}
Handoff instructions from Agent 1: ${analysisReport.handoffToInterviewer}

[Agent 2 Optimizer Brief]:
Upgraded Bullets: ${JSON.stringify(optimizationReport.rewrittenBullets)}
Handoff warnings from Agent 2: ${optimizationReport.handoffToInterviewer}
---

Formulate 4 targeted interview questions probing:
1. Gaps highlighted by Agent 1.
2. Upgraded claims crafted by Agent 2 (to verify if candidate can back them up).
3. Behavioral question using STAR framework.
4. Technical architecture/decision scenario.

Return valid JSON with "interviewStrategy" and array of "questions".
`;

  const result = await callGroqJson<InterviewPack>({
    systemPrompt: SYSTEM_PROMPTS.INTERVIEWER,
    userPrompt,
    apiKey,
  });

  if (result.source === "groq" && result.data && Array.isArray(result.data.questions)) {
    return { data: result.data, source: "groq" };
  }

  return { data: MOCK_INTERVIEWS_AR, source: "mock" };
}

// Agent 4: Answer Evaluator
export async function runEvaluatorAgent(
  question: string,
  userAnswer: string,
  idealPoints: string[],
  apiKey?: string
): Promise<{ data: AnswerEvaluation; source: "groq" | "mock" }> {
  const userPrompt = `
INTERVIEW QUESTION:
${question}

IDEAL CRITERIA / KEY POINTS:
${idealPoints.join("\n- ")}

CANDIDATE'S SUBMITTED ANSWER:
${userAnswer}

Evaluate this answer thoroughly. Output JSON with score (0-100), verdict, strengths, improvements, starBreakdown (situation, task, action, result), and a polished modelAnswer.
`;

  const result = await callGroqJson<AnswerEvaluation>({
    systemPrompt: SYSTEM_PROMPTS.EVALUATOR,
    userPrompt,
    apiKey,
  });

  if (result.source === "groq" && result.data && result.data.score !== undefined) {
    return { data: result.data, source: "groq" };
  }

  return { data: MOCK_EVALUATION_AR, source: "mock" };
}
