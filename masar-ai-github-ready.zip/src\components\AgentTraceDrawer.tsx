"use client";

import React, { useState } from "react";
import { Language, AgentTraceEntry } from "@/types/agents";
import { t } from "@/lib/translations";
import { X, ChevronDown, ChevronUp, Copy, Check, Clock, Cpu } from "lucide-react";

interface AgentTraceDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  traces: AgentTraceEntry[];
  lang: Language;
}

export const AgentTraceDrawer: React.FC<AgentTraceDrawerProps> = ({
  isOpen,
  onClose,
  traces,
  lang,
}) => {
  const strings = t[lang];
  const [expandedId, setExpandedId] = useState<string | null>(traces[0]?.id || null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleToggle = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const handleCopyPayload = (payload: unknown, id: string) => {
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-sm animate-fade-in flex justify-end">
      <div className="w-full max-w-2xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-s border-slate-200 dark:border-slate-800">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/70 dark:bg-slate-800/50">
          <div>
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-teal-600" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                {strings.traceDrawerTitle}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {strings.traceDrawerDesc}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Traces List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {traces.length === 0 ? (
            <div className="text-center py-16 text-slate-400 text-xs">
              {lang === "ar"
                ? "لم يتم تشغيل سرب الوكلاء بعد. اضغط على 'إطلاق سرب الوكلاء' لرؤية مسار البيانات المباشر."
                : "No agent traces recorded yet. Run the pipeline to inspect data handoffs."}
            </div>
          ) : (
            traces.map((trace, idx) => {
              const isExpanded = expandedId === trace.id;
              return (
                <div
                  key={trace.id || idx}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm overflow-hidden"
                >
                  <button
                    onClick={() => handleToggle(trace.id)}
                    className="w-full p-4 text-start flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-800/40 hover:bg-slate-100/50 transition"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-sm">
                        #{idx + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900 dark:text-white">
                            {trace.from} ➔ {trace.to}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                          {trace.summary}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
                        <Clock className="w-3 h-3" />
                        {trace.durationMs}ms
                      </span>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-slate-400" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400" />
                      )}
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-950 text-slate-200 text-xs font-mono space-y-2">
                      <div className="flex items-center justify-between text-slate-400 text-[11px]">
                        <span>{strings.tracePayload}</span>
                        <button
                          onClick={() => handleCopyPayload(trace.payload, trace.id)}
                          className="flex items-center gap-1 text-teal-400 hover:text-teal-300 transition"
                        >
                          {copiedId === trace.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                          <span>{copiedId === trace.id ? strings.copied : strings.copyCode}</span>
                        </button>
                      </div>
                      <pre className="overflow-x-auto p-3 rounded-lg bg-slate-900 border border-slate-800 text-[11px] leading-relaxed max-h-72">
                        {JSON.stringify(trace.payload, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-700 rounded-xl transition"
          >
            {strings.closeDrawer}
          </button>
        </div>
      </div>
    </div>
  );
};
