"use client";

import React from "react";
import { Language, AgentStatus } from "@/types/agents";
import { t } from "@/lib/translations";
import { Search, Sparkles, MessageSquare, ArrowRight, ArrowLeft, Check, Loader2 } from "lucide-react";

interface AgentStatusTimelineProps {
  lang: Language;
  agent1Status: AgentStatus;
  agent2Status: AgentStatus;
  agent3Status: AgentStatus;
  activeTab: number;
  onSelectTab: (tab: number) => void;
}

export const AgentStatusTimeline: React.FC<AgentStatusTimelineProps> = ({
  lang,
  agent1Status,
  agent2Status,
  agent3Status,
  activeTab,
  onSelectTab,
}) => {
  const strings = t[lang];
  const isRtl = lang === "ar";
  const ArrowIcon = isRtl ? ArrowLeft : ArrowRight;

  const agents = [
    {
      id: 1,
      title: strings.agent1Title,
      short: lang === "ar" ? "وكيل الفرز والتحليل" : "ATS Analyzer Agent",
      status: agent1Status,
      icon: Search,
      color: "teal",
    },
    {
      id: 2,
      title: strings.agent2Title,
      short: lang === "ar" ? "وكيل إعادة الصياغة" : "Resume Optimizer Agent",
      status: agent2Status,
      icon: Sparkles,
      color: "emerald",
    },
    {
      id: 3,
      title: strings.agent3Title,
      short: lang === "ar" ? "وكيل إعداد المقابلات" : "Interview Coach Agent",
      status: agent3Status,
      icon: MessageSquare,
      color: "cyan",
    },
  ];

  const getStatusBadge = (status: AgentStatus) => {
    switch (status) {
      case "running":
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-600 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full border border-amber-200">
            <Loader2 className="w-3 h-3 animate-spin" />
            {lang === "ar" ? "قيد المعالجة..." : "Working..."}
          </span>
        );
      case "done":
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-200">
            <Check className="w-3 h-3" />
            {lang === "ar" ? "اكتمل" : "Ready"}
          </span>
        );
      case "error":
        return (
          <span className="text-[11px] font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full">
            {lang === "ar" ? "تعذر" : "Error"}
          </span>
        );
      default:
        return (
          <span className="text-[11px] text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">
            {lang === "ar" ? "في الانتظار" : "Standby"}
          </span>
        );
    }
  };

  return (
    <div className="w-full bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm mb-6">
      <div className="flex items-center justify-between mb-3">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          {lang === "ar" ? "تسلسل التعاون بين الوكلاء (Agent Pipeline Workflow)" : "Sequential Multi-Agent Collaboration Pipeline"}
        </h4>
        <span className="text-[11px] text-slate-400">
          {lang === "ar" ? "تسليم آلي للمخرجات بين الوكلاء" : "Automated Inter-Agent Handoffs"}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 relative">
        {agents.map((agent, idx) => {
          const Icon = agent.icon;
          const isSelected = activeTab === agent.id;
          return (
            <div key={agent.id} className="relative flex items-center">
              <button
                onClick={() => onSelectTab(agent.id)}
                className={`w-full text-start p-3.5 rounded-xl border transition-all ${
                  isSelected
                    ? "border-teal-500 bg-teal-50/50 dark:bg-teal-950/20 shadow-sm ring-1 ring-teal-500/30"
                    : "border-slate-200 hover:border-slate-300 dark:border-slate-800 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40"
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center font-bold text-xs shadow-sm">
                      {agent.id}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {agent.short}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {agent.id === 1 && (lang === "ar" ? "يستخرج الفجوات والكلمات" : "Extracts Gaps & Keywords")}
                        {agent.id === 2 && (lang === "ar" ? "يعيد الصياغة بصيغة XYZ" : "XYZ Impact Transformation")}
                        {agent.id === 3 && (lang === "ar" ? "يصمم أسئلة التحدي والـ STAR" : "Targeted STAR Questions")}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-slate-200/50 dark:border-slate-700/50">
                  <span className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Icon className="w-3.5 h-3.5 text-teal-600" />
                    <span>{agent.id === 1 ? "Agent 1" : agent.id === 2 ? "Agent 2" : "Agent 3"}</span>
                  </span>
                  {getStatusBadge(agent.status)}
                </div>
              </button>

              {/* Arrow Connector for Desktop */}
              {idx < agents.length - 1 && (
                <div className="hidden md:flex absolute -right-2 rtl:-right-auto rtl:-left-2 z-10 w-4 h-4 rounded-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 items-center justify-center shadow-sm text-slate-400">
                  <ArrowIcon className="w-2.5 h-2.5" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
