export type Language = "ar" | "en";

export type AgentStatus = "idle" | "running" | "done" | "error";

export interface MissingKeyword {
  keyword: string;
  priority: "high" | "medium";
  reason: string;
}

export interface SkillGap {
  area: string;
  issue: string;
  impact: string;
}

export interface AnalysisReport {
  atsScore: number; // 0-100
  matchLevel: "low" | "medium" | "high";
  candidateSummary: string;
  targetRole: string;
  strengths: string[];
  missingKeywords: MissingKeyword[];
  skillGaps: SkillGap[];
  handoffToOptimizer: string;
  handoffToInterviewer: string;
}

export interface RewrittenBullet {
  original: string;
  improved: string;
  keywordsAdded: string[];
  rationale: string;
}

export interface OptimizationReport {
  projectedAtsScore: number;
  scoreImprovementNote: string;
  optimizedSummary: string;
  rewrittenBullets: RewrittenBullet[];
  suggestedSkills: string[];
  atsFormattingTips: string[];
  handoffToInterviewer: string;
}

export interface InterviewQuestion {
  id: string;
  sourceAgent: "analyzer" | "optimizer";
  targetFocus: string;
  category: "technical" | "behavioral" | "gap-probe" | "experience-verify";
  difficulty: "medium" | "hard";
  question: string;
  whyAsked: string;
  hint: string;
  idealPoints: string[];
}

export interface InterviewPack {
  interviewStrategy: string;
  questions: InterviewQuestion[];
}

export interface StarBreakdown {
  situation: boolean;
  task: boolean;
  action: boolean;
  result: boolean;
}

export interface AnswerEvaluation {
  score: number; // 0-100
  verdict: string;
  strengths: string[];
  improvements: string[];
  starBreakdown: StarBreakdown;
  modelAnswer: string;
}

export interface AgentTraceEntry {
  id: string;
  from: string;
  to: string;
  timestamp: string;
  durationMs: number;
  summary: string;
  payload: unknown;
}
