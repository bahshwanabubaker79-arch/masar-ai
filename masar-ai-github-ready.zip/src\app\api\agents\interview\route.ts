import { NextRequest, NextResponse } from "next/server";
import { runInterviewerAgent } from "@/lib/groq";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { analysisReport, optimizationReport, apiKey } = body;

    if (!analysisReport || !optimizationReport) {
      return NextResponse.json(
        { error: "Both Agent 1 Analysis and Agent 2 Optimization reports are required" },
        { status: 400 }
      );
    }

    const headerApiKey = req.headers.get("x-groq-key") || undefined;
    const effectiveKey = apiKey || headerApiKey;

    const startTime = Date.now();
    const result = await runInterviewerAgent(analysisReport, optimizationReport, effectiveKey);
    const durationMs = Date.now() - startTime;

    return NextResponse.json({
      success: true,
      data: result.data,
      source: result.source,
      durationMs,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
