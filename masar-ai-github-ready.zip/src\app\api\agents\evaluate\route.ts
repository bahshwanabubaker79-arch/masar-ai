import { NextRequest, NextResponse } from "next/server";
import { runEvaluatorAgent } from "@/lib/groq";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { question, userAnswer, idealPoints, apiKey } = body;

    if (!question || !userAnswer) {
      return NextResponse.json(
        { error: "Question and User Answer are required" },
        { status: 400 }
      );
    }

    const headerApiKey = req.headers.get("x-groq-key") || undefined;
    const effectiveKey = apiKey || headerApiKey;

    const startTime = Date.now();
    const result = await runEvaluatorAgent(
      question,
      userAnswer,
      idealPoints || [],
      effectiveKey
    );
    const durationMs = Date.now() - startTime;

    return NextResponse.json({
      success: true,
      data: result.data,
      source: result.source,
      durationMs,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
