"use client";

import React from "react";
import { Language } from "@/types/agents";
import { t } from "@/lib/translations";
import { Sparkles, Key, FileText, Globe } from "lucide-react";

interface NavbarProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenApiKeyModal: () => void;
  onOpenTraceDrawer: () => void;
  hasCustomKey: boolean;
  traceCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  lang,
  onToggleLang,
  onOpenApiKeyModal,
  onOpenTraceDrawer,
  hasCustomKey,
  traceCount,
}) => {
  const strings = t[lang];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/90 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 to-emerald-400 flex items-center justify-center text-white shadow-md shadow-teal-500/20">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-teal-600 via-emerald-600 to-cyan-600 bg-clip-text text-transparent">
                {strings.appName}
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 border border-teal-200 dark:bg-teal-950/60 dark:text-teal-300 dark:border-teal-800">
                Multi-Agent
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
              {strings.appTagline}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Agent Trace Drawer Trigger */}
          <button
            onClick={onOpenTraceDrawer}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 text-slate-700 bg-slate-50 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 transition"
            title={strings.navTrace}
          >
            <FileText className="w-4 h-4 text-teal-600" />
            <span className="hidden md:inline">{strings.navTrace}</span>
            {traceCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-teal-600 text-white">
                {traceCount}
              </span>
            )}
          </button>

          {/* Groq Key Modal Trigger */}
          <button
            onClick={onOpenApiKeyModal}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition ${
              hasCustomKey
                ? "border-emerald-300 bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:border-emerald-700 dark:text-emerald-300"
                : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300"
            }`}
          >
            <Key className={`w-3.5 h-3.5 ${hasCustomKey ? "text-emerald-600" : "text-amber-500"}`} />
            <span className="hidden sm:inline">
              {hasCustomKey ? "Groq (Active)" : "Groq API"}
            </span>
          </button>

          {/* Language Switcher */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-600 text-white hover:bg-teal-700 shadow-sm transition"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{strings.navLanguage}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
