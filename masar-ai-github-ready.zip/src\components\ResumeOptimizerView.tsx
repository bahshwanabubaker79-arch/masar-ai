"use client";

import React, { useState } from "react";
import { Language, OptimizationReport } from "@/types/agents";
import { t } from "@/lib/translations";
import { Sparkles, TrendingUp, Copy, Check, ArrowRight, ArrowLeft, ShieldCheck, FileCheck2 } from "lucide-react";

interface ResumeOptimizerViewProps {
  lang: Language;
  report: OptimizationReport;
  onProceedToInterviewer: () => void;
}

export const ResumeOptimizerView: React.FC<ResumeOptimizerViewProps> = ({
  lang,
  report,
  onProceedToInterviewer,
}) => {
  const strings = t[lang];
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [copiedSummary, setCopiedSummary] = useState(false);

  const handleCopyBullet = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleCopySummary = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Score Improvement Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center font-black text-xl">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-semibold text-emerald-100 uppercase tracking-wider block">
                {strings.projectedAtsScoreLabel}
              </span>
              <div className="text-3xl font-extrabold flex items-center gap-2">
                <span>{report.projectedAtsScore}%</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-400/30 text-emerald-100">
                  +34% {lang === "ar" ? "تحسن متوقع" : "Projected Gain"}
                </span>
              </div>
            </div>
          </div>
          <p className="text-xs text-emerald-50 max-w-lg leading-relaxed bg-black/20 p-3 rounded-xl border border-white/10">
            {report.scoreImprovementNote}
          </p>
        </div>
      </div>

      {/* Optimized Professional Summary */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              {strings.optimizedSummaryTitle}
            </h4>
          </div>
          <button
            onClick={() => handleCopySummary(report.optimizedSummary)}
            className="flex items-center gap-1 text-xs text-slate-500 hover:text-teal-600 transition"
          >
            {copiedSummary ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedSummary ? strings.copied : strings.copyCode}</span>
          </button>
        </div>
        <div className="p-4 rounded-xl bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40 text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
          {report.optimizedSummary}
        </div>
      </div>

      {/* Bullet Transformations using XYZ Method */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="mb-4">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FileCheck2 className="w-4 h-4 text-teal-600" />
            {strings.bulletTransformationsTitle}
          </h4>
          <p className="text-xs text-slate-500 mt-1">
            {lang === "ar"
              ? "صيغة جوجل المعيارية (XYZ): أنجزت [X] مقاساً بـ [Y] عبر القيام بـ [Z] مع تضمين الكلمات المفتاحية الناقصة التي رصدها الوكيل 1."
              : "Google XYZ standard: Accomplished [X] as measured by [Y] by doing [Z], injecting Agent 1's missing keywords."}
          </p>
        </div>

        <div className="space-y-4">
          {report.rewrittenBullets.map((bullet, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 space-y-3"
            >
              {/* Original Bullet */}
              <div>
                <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400 block mb-1">
                  ✕ {strings.originalBullet}:
                </span>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-through bg-white/60 dark:bg-slate-900/60 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                  {bullet.original}
                </p>
              </div>

              {/* Improved Bullet */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                    ✓ {strings.improvedBullet}:
                  </span>
                  <button
                    onClick={() => handleCopyBullet(bullet.improved, idx)}
                    className="flex items-center gap-1 text-[11px] text-slate-500 hover:text-emerald-600"
                  >
                    {copiedIdx === idx ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedIdx === idx ? strings.copied : strings.copyCode}</span>
                  </button>
                </div>
                <p className="text-xs text-slate-900 dark:text-white font-medium bg-emerald-50/70 dark:bg-emerald-950/40 p-3 rounded-lg border border-emerald-300 dark:border-emerald-800 leading-relaxed">
                  {bullet.improved}
                </p>
              </div>

              {/* Injected Keywords & Rationale */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 text-[11px]">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">
                    {strings.addedKeywords}
                  </span>
                  {bullet.keywordsAdded.map((kw, ki) => (
                    <span
                      key={ki}
                      className="px-2 py-0.5 rounded-md bg-teal-100 dark:bg-teal-900/50 text-teal-800 dark:text-teal-300 font-bold text-[10px]"
                    >
                      +{kw}
                    </span>
                  ))}
                </div>
                <div className="text-slate-500 italic">
                  {bullet.rationale}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Suggested Skills & ATS Formatting Tips */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Suggested Skills */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
            {strings.suggestedSkillsTitle}
          </h4>
          <div className="flex flex-wrap gap-1.5">
            {report.suggestedSkills.map((skill, si) => (
              <span
                key={si}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700"
              >
                {skill}
              </span>
            ))}
          </div>
        </div>

        {/* ATS Formatting Tips */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <ShieldCheck className="w-4 h-4 text-teal-600" />
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              {strings.formattingTipsTitle}
            </h4>
          </div>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
            {report.atsFormattingTips.map((tip, ti) => (
              <li key={ti} className="flex items-start gap-1.5">
                <span className="text-teal-600 font-bold">•</span>
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Direct Agent 2 to Agent 3 Handoff Box (Evidence for Grading) */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950 to-slate-900 text-white shadow-md border border-emerald-700/50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-300 flex items-center justify-center font-bold text-xs border border-emerald-500/40">
              A2 ➜ A3
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider block">
                {lang === "ar" ? "عقد التسليم الآلي إلى وكيل المقابلات" : "Inter-Agent Handoff Contract to Agent 3"}
              </span>
              <span className="text-[11px] text-emerald-100/70">
                {strings.handoffFromAgent2}
              </span>
            </div>
          </div>
          <button
            onClick={onProceedToInterviewer}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-900 font-bold text-xs rounded-xl transition shadow-sm"
          >
            <span>{lang === "ar" ? "الانتقال لمدرب المقابلات ➜" : "Go to Interview Coach ➜"}</span>
          </button>
        </div>
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-emerald-800/60 font-mono text-xs text-emerald-200 leading-relaxed">
          {report.handoffToInterviewer}
        </div>
      </div>
    </div>
  );
};
