"use client";

import React, { useState } from "react";
import { Language, InterviewPack, InterviewQuestion, AnswerEvaluation } from "@/types/agents";
import { t } from "@/lib/translations";
import {
  MessageSquare,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  Send,
  Loader2,
  Award,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  Bot,
} from "lucide-react";

interface InterviewCoachViewProps {
  lang: Language;
  pack: InterviewPack;
  apiKey: string;
}

export const InterviewCoachView: React.FC<InterviewCoachViewProps> = ({
  lang,
  pack,
  apiKey,
}) => {
  const strings = t[lang];
  const [selectedQuestion, setSelectedQuestion] = useState<InterviewQuestion>(
    pack.questions[0] || null
  );
  const [userAnswer, setUserAnswer] = useState("");
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluation, setEvaluation] = useState<AnswerEvaluation | null>(null);

  const handleSelectQuestion = (q: InterviewQuestion) => {
    setSelectedQuestion(q);
    setEvaluation(null);
  };

  const handleFillSampleAnswer = () => {
    if (lang === "ar") {
      setUserAnswer(
        "في مشروعي الأخير واجهنا مشكلة في وقت تحميل الصفحة الرئيسية التي تحتوي على لوحة تحكم ثقيلة (الموقف). كان المطلوب مني تقليل زمن التحميل إلى أقل من ثانيتين لتحسين تجربة الاستخدام (المهمة). قمت بتحليل الـ Bundle باستخدام webpack-bundle-analyzer واستبدلت الاستيراد المباشر بالـ Lazy Loading عبر Dynamic Imports واستخدمت Server Components مع تحسين الصور (الإجراء). النتيجة كانت انخفاض زمن أول ظهور للمحتوى بنسبة 35% وارتفاع نتيجة Lighthouse إلى 94% (النتيجة)."
      );
    } else {
      setUserAnswer(
        "In our capstone project, our main dashboard page took over 4 seconds to load (Situation). I was tasked with bringing the initial load time down under 2 seconds to meet project performance goals (Task). I analyzed the bundle with Webpack analyzer, introduced React lazy loading for charts, and migrated heavy data rendering to Next.js Server Components with optimized images (Action). As a result, page load time dropped by 35% and our Lighthouse score jumped from 60 to 94 (Result)."
      );
    }
  };

  const handleSubmitAnswer = async () => {
    if (!userAnswer.trim() || !selectedQuestion) return;
    setIsEvaluating(true);
    setEvaluation(null);

    try {
      const res = await fetch("/api/agents/evaluate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(apiKey ? { "x-groq-key": apiKey } : {}),
        },
        body: JSON.stringify({
          question: selectedQuestion.question,
          userAnswer,
          idealPoints: selectedQuestion.idealPoints,
          apiKey,
        }),
      });

      const json = await res.json();
      if (json.data) {
        setEvaluation(json.data);
      }
    } catch (err) {
      console.error("Evaluation error:", err);
    } finally {
      setIsEvaluating(false);
    }
  };

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case "gap-probe":
        return {
          label: lang === "ar" ? "فحص فجوة رصدها الوكيل 1" : "Agent 1 Gap Probe",
          color: "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300",
        };
      case "experience-verify":
        return {
          label: lang === "ar" ? "التحقق من إضافات الوكيل 2" : "Agent 2 Claim Verify",
          color: "bg-teal-100 text-teal-800 dark:bg-teal-950/40 dark:text-teal-300",
        };
      case "behavioral":
        return {
          label: lang === "ar" ? "سلوكي (STAR Framework)" : "Behavioral (STAR)",
          color: "bg-indigo-100 text-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-300",
        };
      default:
        return {
          label: lang === "ar" ? "تقني معماري" : "Technical Scenario",
          color: "bg-cyan-100 text-cyan-800 dark:bg-cyan-950/40 dark:text-cyan-300",
        };
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Strategy Card */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-900 via-teal-900 to-slate-900 text-white shadow-md border border-cyan-700/50">
        <div className="flex items-center gap-2 mb-2 text-cyan-300 text-xs font-bold uppercase tracking-wider">
          <Bot className="w-4 h-4" />
          <span>{strings.interviewStrategyTitle}</span>
        </div>
        <p className="text-sm text-cyan-50 leading-relaxed font-medium">
          {pack.interviewStrategy}
        </p>
      </div>

      {/* Main Split: Questions List on Left, Active Practice on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Questions Selector (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            {strings.selectQuestionPrompt}
          </span>
          <div className="space-y-2.5">
            {pack.questions.map((q, idx) => {
              const isSelected = selectedQuestion?.id === q.id;
              const badge = getCategoryBadge(q.category);
              return (
                <button
                  key={q.id || idx}
                  onClick={() => handleSelectQuestion(q)}
                  className={`w-full text-start p-3.5 rounded-xl border transition-all ${
                    isSelected
                      ? "border-teal-500 bg-white dark:bg-slate-900 shadow-md ring-2 ring-teal-500/20"
                      : "border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 hover:bg-white dark:hover:bg-slate-800"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                      Q{idx + 1}
                    </span>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${badge.color}`}>
                      {badge.label}
                    </span>
                  </div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white line-clamp-2 leading-snug">
                    {q.question}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Question Details & Simulator (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {selectedQuestion && (
            <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              {/* Question Text */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-bold text-teal-600 uppercase tracking-wider">
                    {selectedQuestion.targetFocus}
                  </span>
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white leading-relaxed">
                  "{selectedQuestion.question}"
                </h3>
              </div>

              {/* Coaching Intelligence: Why asked & Hint */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-700/60">
                  <div className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300 mb-1">
                    <HelpCircle className="w-3.5 h-3.5 text-teal-600" />
                    <span>{strings.whyAskedLabel}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
                    {selectedQuestion.whyAsked}
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/40">
                  <div className="flex items-center gap-1.5 font-bold text-amber-900 dark:text-amber-300 mb-1">
                    <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
                    <span>{strings.hintLabel}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
                    {selectedQuestion.hint}
                  </p>
                </div>
              </div>

              {/* Ideal Key Points */}
              <div className="p-3 rounded-xl bg-teal-50/40 dark:bg-teal-950/20 border border-teal-200/60 dark:border-teal-900/40">
                <span className="text-[11px] font-bold text-teal-900 dark:text-teal-300 block mb-1.5">
                  {strings.idealCriteriaLabel}
                </span>
                <ul className="text-xs text-slate-700 dark:text-slate-300 space-y-1">
                  {selectedQuestion.idealPoints.map((pt, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-teal-600 flex-shrink-0" />
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Answer Input Simulator */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    {strings.yourAnswerLabel}
                  </label>
                  <button
                    onClick={handleFillSampleAnswer}
                    className="text-[11px] text-teal-600 hover:underline font-semibold"
                  >
                    {lang === "ar" ? "تعبئة إجابة نموذجية بأسلوب STAR للتجربة السريعة" : "Fill STAR Sample Answer"}
                  </button>
                </div>
                <textarea
                  rows={4}
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  placeholder={strings.yourAnswerPlaceholder}
                  className="w-full p-3 text-xs sm:text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 leading-relaxed font-sans"
                />

                <div className="flex justify-end">
                  <button
                    disabled={!userAnswer.trim() || isEvaluating}
                    onClick={handleSubmitAnswer}
                    className="flex items-center gap-2 px-5 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white font-bold text-xs rounded-xl shadow-sm transition"
                  >
                    {isEvaluating ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>{strings.evaluatingAnswer}</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>{strings.evaluateBtn}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Real-time Agent 4 Evaluation Card */}
              {evaluation && (
                <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-50 to-teal-50/30 dark:from-slate-900 dark:to-teal-950/20 border border-teal-200 dark:border-teal-800 shadow-sm space-y-4 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Award className="w-5 h-5 text-teal-600" />
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                        {strings.evaluationResultTitle}
                      </h4>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500">{strings.scoreBadge}:</span>
                      <span className="text-xl font-extrabold px-3 py-0.5 rounded-lg bg-teal-600 text-white shadow-sm">
                        {evaluation.score}/100
                      </span>
                    </div>
                  </div>

                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 bg-white/80 dark:bg-slate-800/80 p-3 rounded-xl border border-slate-200 dark:border-slate-700">
                    {evaluation.verdict}
                  </p>

                  {/* STAR Method Breakdown Indicators */}
                  <div>
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                      {strings.starGridTitle}
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                      <div
                        className={`p-2 rounded-lg font-bold border ${
                          evaluation.starBreakdown.situation
                            ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                            : "bg-rose-50 text-rose-800 border-rose-300"
                        }`}
                      >
                        {evaluation.starBreakdown.situation ? "✓" : "✕"} {strings.starSituation}
                      </div>
                      <div
                        className={`p-2 rounded-lg font-bold border ${
                          evaluation.starBreakdown.task
                            ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                            : "bg-rose-50 text-rose-800 border-rose-300"
                        }`}
                      >
                        {evaluation.starBreakdown.task ? "✓" : "✕"} {strings.starTask}
                      </div>
                      <div
                        className={`p-2 rounded-lg font-bold border ${
                          evaluation.starBreakdown.action
                            ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                            : "bg-rose-50 text-rose-800 border-rose-300"
                        }`}
                      >
                        {evaluation.starBreakdown.action ? "✓" : "✕"} {strings.starAction}
                      </div>
                      <div
                        className={`p-2 rounded-lg font-bold border ${
                          evaluation.starBreakdown.result
                            ? "bg-emerald-50 text-emerald-800 border-emerald-300"
                            : "bg-rose-50 text-rose-800 border-rose-300"
                        }`}
                      >
                        {evaluation.starBreakdown.result ? "✓" : "✕"} {strings.starResult}
                      </div>
                    </div>
                  </div>

                  {/* Strengths & Improvements */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div className="p-3 rounded-xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200">
                      <span className="font-bold text-emerald-900 dark:text-emerald-300 block mb-1">
                        {lang === "ar" ? "نقاط القوة في إجابتك:" : "Strengths:"}
                      </span>
                      <ul className="space-y-1 text-slate-700 dark:text-slate-300 text-[11px]">
                        {evaluation.strengths.map((s, i) => (
                          <li key={i}>• {s}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-3 rounded-xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200">
                      <span className="font-bold text-amber-900 dark:text-amber-300 block mb-1">
                        {lang === "ar" ? "فرص التحسين والتطوير:" : "Areas to Improve:"}
                      </span>
                      <ul className="space-y-1 text-slate-700 dark:text-slate-300 text-[11px]">
                        {evaluation.improvements.map((m, i) => (
                          <li key={i}>• {m}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Exemplary Model Answer */}
                  <div className="p-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                    <div className="flex items-center gap-1.5 font-bold text-xs text-teal-700 dark:text-teal-300 mb-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{strings.modelAnswerTitle}</span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed font-sans">
                      {evaluation.modelAnswer}
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
